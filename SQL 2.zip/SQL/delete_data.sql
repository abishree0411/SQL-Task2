-- Delete employees with salary < 30000
DELETE FROM Employees
WHERE Salary < 30000;