-- Update missing department
UPDATE Employees
SET Department = 'Admin'
WHERE Department IS NULL;

-- Increase salary of IT employees
UPDATE Employees
SET Salary = Salary + 5000
WHERE Department = 'IT';