CREATE TABLE Employees (
    EmpID INTEGER PRIMARY KEY,
    Name TEXT NOT NULL,
    Department TEXT,
    Salary REAL DEFAULT 25000
);