-- Insert with full data
INSERT INTO Employees (EmpID, Name, Department, Salary) VALUES (1, 'Alice', 'HR', 35000);
INSERT INTO Employees (EmpID, Name, Department, Salary) VALUES (2, 'Bob', 'IT', 40000);

-- Insert with NULL Department
INSERT INTO Employees (EmpID, Name, Department, Salary) VALUES (3, 'Charlie', NULL, 28000);

-- Insert using default salary
INSERT INTO Employees (EmpID, Name, Department) VALUES (4, 'Diana', 'Finance');